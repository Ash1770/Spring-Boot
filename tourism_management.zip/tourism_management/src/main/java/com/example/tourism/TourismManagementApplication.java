package com.example.tourism;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TourismManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(TourismManagementApplication.class, args);
	}

}
