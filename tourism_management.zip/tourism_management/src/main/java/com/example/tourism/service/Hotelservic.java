package com.example.tourism.service;

import java.util.List;

import com.example.tourism.entity.Hotel;
import com.example.tourism.entity.User;

public interface Hotelservic {
	Hotel SaveHotel(Hotel hotel);
    List<Hotel>GetAllhotel();
    
    
   
   
}
