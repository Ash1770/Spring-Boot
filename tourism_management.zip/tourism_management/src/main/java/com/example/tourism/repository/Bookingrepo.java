package com.example.tourism.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.tourism.entity.Booking;
import com.example.tourism.entity.Hotel;
import com.example.tourism.entity.Transport;
import com.example.tourism.entity.User;

public interface Bookingrepo extends JpaRepository <Booking ,Long>{
	

	
}
