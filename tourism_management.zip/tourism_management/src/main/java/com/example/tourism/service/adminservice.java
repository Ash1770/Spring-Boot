package com.example.tourism.service;

import com.example.tourism.entity.Admin;
import com.example.tourism.entity.Hotel;

public interface adminservice {
	Admin saveAdmin(Admin admin);
	Admin username(String username);
	
	
}
